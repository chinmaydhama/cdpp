# <a href="https://vaishnavipatil29.github.io/" target="_blank">My Portfolio Website</a>

[![Repository Status](https://img.shields.io/badge/Repository%20Status-Maintained-dark%20green.svg)](https://github.com/vaishnavipatil29/vaishnavipatil29.github.io/)
[![Website Status](https://img.shields.io/badge/Website%20Status-Online-green)](https://vaishnavipatil29.github.io)
[![Author](https://img.shields.io/badge/Author-Vaishnavi%20Patil-blue.svg)](https://www.linkedin.com/in/vaishnavi-patil-75a714173//)

 <p align="justify">This website serves as an online portfolio to showcase my web presence, résumé, story, & featured projects.</p>
 
Please ping me at vaishshells@gmail.com if you have any feedback or ideas for the website. Leave a :star: &nbsp;if you like it!
